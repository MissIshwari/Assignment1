def check_password_strength(password):
    # print(password)
    upper=False
    lower=False
    digit=False
    special_char=False
    if(len(password)>=8):
        for i in range(len(password)):
            if(password[i].isalpha()):
                if(password[i].isupper()):
                    upper=True
                    break
        
        for i in range(len(password)):
            if(password[i].isalpha()):
                if(password[i].islower()):
                    lower=True
                    break

        for i in range(len(password)):
            if(password[i].isdigit()):
                digit=True
                break

        for i in range(len(password)):
            if((not password[i].isdigit()) and (not password[i].isalpha())):
                # print(password[i])
                special_char=True
                break
                # digit=True
                # break

        
        
        if(upper==True and lower==True and digit==True and special_char==True):
            return True
        
        else:
            return False



        
    else:
        return False




password=input('Enter password: ')
# print(password)
criteria=check_password_strength(password)

if(criteria==True):
    print("Password is strong")
else:
    print("Password is not strong")