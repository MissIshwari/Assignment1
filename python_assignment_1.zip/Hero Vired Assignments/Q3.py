from pymongo import MongoClient
from flask import Flask
import os
import configparser
from bson.json_util import dumps


# db_config={}

app = Flask(__name__)
config_path='./config.ini'

@app.route("/")
def read_config():
    try:
        if(os.path.exists(config_path)):
            try:
                config=configparser.ConfigParser()
                config.read(config_path)
                sections=config.sections()
                global db_config
                db_config={}
                for section in sections:
                    if section=='Database':
                        db_config['connection_string']=config[section]['connection_string']
                        return "Config read."
            except:
                print("Some error occurred")
        else:
            raise FileNotFoundError("File not found.")
    except FileNotFoundError as e:
        print(e)

@app.route("/database-details")
def get_db():
    
    CONNECTION_STRING=db_config['connection_string']
    client=MongoClient(CONNECTION_STRING)
    db=client['db-config']
    collection=db['mongo-db']
    collection.insert_one(db_config)

    item_details = collection.find()

    list_cur = list(item_details)

    json_data = dumps(list_cur)
    return json_data

if __name__ == "__main__":
    app.run(debug=True)