import psutil
import time

def cpu_tracker():
    print("Monitoring CPU usage...")
    try:
        while True:
            time.sleep(2)
            print(psutil.cpu_percent())
            cpu_percent_use=psutil.cpu_percent()
            if(cpu_percent_use>80):
                print("Alert! CPU usage exceeds threshold: "+str(cpu_percent_use)+"%")
    
    except KeyboardInterrupt:
        print("Program was interrupted")

cpu_tracker()




