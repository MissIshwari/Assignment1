import shutil
import os
import time
from datetime import datetime  
import sys



def backup(source_dir,dest_dir):
    try:
        if(os.path.exists(source_dir) and os.path.exists(dest_dir)):
            src_files=os.listdir(source_dir)
            for file in src_files:
            
                src_file_name = os.path.join(source, file)
                dest_file_name=os.path.join(destination, file)
           
                if(os.path.isfile(src_file_name)):
                    if(os.path.exists(dest_file_name)):
                        name_and_extension=file.split(".")

                        timestamp = datetime.fromtimestamp(time.time())
                        file=name_and_extension[0]+timestamp.strftime(" %d-%m-%Y %H %M %S")+"."+name_and_extension[1]
                        dest_file_name=os.path.join(destination,file)

                    shutil.copy(src_file_name,dest_file_name)
        else:
            raise FileNotFoundError("Source or destination folder does not exist.")
    except FileNotFoundError as e:
        print(e)

source=sys.argv[1]
destination=sys.argv[2]
backup(source,destination)